
/*menu js start*/

function menuOnClick() {
  document.getElementById("menu-bar").classList.toggle("change");
  document.getElementById("nav").classList.toggle("change");
  document.getElementById("menu-bg").classList.toggle("change-bg");
}

/*menu js end*/


/*slider js start*/

$( document ).ready(function() {

var $carousel = $('.carousel').flickity({
        autoPlay: true,
        prevNextButtons: false,
        pageDots: false,
      }
  );



$carousel.on( 'select.flickity', function( event, index ) {
  var dataColor = $(this).find(".is-selected").data("bg-color"); 

  if($(window).width() > 767){
     $(".body-bg-color").css({ 'background-color': dataColor });
  }
  else{
    $(".body-bg-color").css({ 'background-color': '#FFF' });
  }
  $(".carousel").css({ 'background-color': dataColor });
});
});

/*slider js end*/

/*multi image slider js start*/


$('.autoplay-slider').slick({
    slidesToShow: 3,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 4000, 
    /*arrows: true,*/
    speed: 800,
    responsive: [
    {
      breakpoint: 768,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 3,
        infinite: true,
        dots: false,
        arrows:false
      }
    },
    {
      breakpoint: 480,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1,
        dots: false,
        arrows:false
      }
    }    
  ]


  });

/*multi imagr slider js end*/

/*back to top js start*/

$(function() {  
    $('a[href^="#"]').on('click',function (e) {  
    if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') && location.hostname == this.hostname) {      
      var target = $(this.hash);
      target = target.length ? target : $('[name=' + this.hash.slice(1) +']');
      if (target.length) {
        $('html,body').animate({
          scrollTop: target.offset().top -50
        }, 1000);
        return false;
      }
    }
  });
});

/*back to top js end*/
